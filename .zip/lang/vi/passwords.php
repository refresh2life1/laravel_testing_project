<?php

return [
    'reset' => 'Mật khẩu đã được cập nhật!',
    'sent' => 'Chúng tôi đã gửi cho bạn đường dẫn thay đổi mật khẩu!',
    'token' => 'Mã xác nhận mật khẩu không hợp lệ.',
    'user' => 'Không tìm thấy thành viên với địa chỉ email này.',
];
